#include "holberton.h"

/**
 * reset_to_98 - function that takes a pointer and updates its value to 98
 * Description: Program that resets to 98
 * @n: the interger to reset to
 *
 */
void reset_to_98(int *n)
{
	*n = 98;
}
